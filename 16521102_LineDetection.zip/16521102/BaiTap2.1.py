import cv2
import numpy
import random
import math

class mypoint:
    def __init__ (self, xx, yy):
        self.x = xx
        self.y = yy

class model:
#    def __init__ (self, aa, bb):
#        self.a = aa
#        self.b = bb
    def __init__ (self, p1, p2):
        self.a = p2.y - p1.y
        self.b = p1.x - p2.x
        self.c = - self.a*p1.x - self.b*p1.y 
    def check (self, x ,y):
        t = (self.a*x + self.b*y + self.c) / math.sqrt(math.pow(self.a, 2) + math.pow(self.b, 2))
        if t <= 2 and t >= -2:
            return True
        return False
    
def RANSAC(data, k):
    best_model = model(data[0], data[1])
    best_pc = 0
    best_plist = []
    
    for i in range(k):
        plist = []
        p1 = data[random.randint(0,len(data) - 1)]
        p2 = data[random.randint(0,len(data) - 1)]
        while (p1.x == p2.x or p1.y == p2.y):
            p2 = data[random.randint(0,len(data) - 1)]
    
        rmodel = model(p1, p2) 
        for j in data:
            if rmodel.check(j.x, j.y):
                plist.append(j)
        if len(plist) > best_pc:
            best_model = rmodel
            best_pc = len(plist)
            best_plist = plist
    return best_model, best_plist


      
win = numpy.zeros((300,800))
win = (win).astype('uint8')
#cv2.imshow('line', win)

data =[]
for i in range(140):
    x = random.randint(0,200)
    y = 3*x+random.randint(0,14)
    a = mypoint(x, y)
    data.append(a)

for i in range(60):
    x = random.randint(0,200)
    y = 3*x+random.randint(-56,70)
    a = mypoint(x, y)
    data.append(a)

for i in data:
    win[i.x][i.y] = 255

cv2.imshow('line1', win)

for i in data:
    win[i.x][i.y] = 0

r=RANSAC(data,12)
for i in r[1]:
    win[i.x][i.y] = 255
cv2.imshow('line2', win)

#lx = [x = random.randint()

cv2.waitKey(0)
cv2.destroyAllWindows()



