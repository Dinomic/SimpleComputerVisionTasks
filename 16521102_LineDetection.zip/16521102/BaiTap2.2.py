import cv2 as cv
import numpy as np
import math

def draw (img, rho, theta):
    
    si = math.sin(theta*math.pi/180)
    co = math.cos(theta*math.pi/180)
    if (si > co):
        for x in range(len(img)):
            y = int((rho - x*co) / si)
            img[x][y] = 255
    else:
        for y in range(len(img[0])):
            x = int((rho - y*si) / co)
            img[x][y] = 255


def hough_lines_draw(img, rho, theta):
        a = np.cos(theta*math.pi/180)
        b = np.sin(theta*math.pi/180)
        x0 = a*rho
        y0 = b*rho
        
        x1 = int(x0 + 1000*(-b))
        y1 = int(y0 + 1000*(a))
        x2 = int(x0 - 1000*(-b))
        y2 = int(y0 - 1000*(a))

        cv.line(img, (x1, y1), (x2, y2), (0, 0, 255), 2)

def another_draw_func(data, img, rho, theta):
    for S in data:
        if rho == int(math.fabs(S[1]*math.cos(theta) + S[0]*math.sin(theta))):
            img[S[0]][S[1]] = (0, 0, 255)
            img[S[0] + 1][S[1]] = (0, 0, 255)
            img[S[0] - 1][S[1]] = (0, 0, 255)
            img[S[0]][S[1] + 1] = (0, 0, 255)
            img[S[0]][S[1] - 1] = (0, 0, 255)
            img[S[0] + 1][S[1] + 1] = (0, 0, 255)
            img[S[0] - 1][S[1] - 1] = (0, 0, 255)
            img[S[0] - 1][S[1] + 1] = (0, 0, 255)
            img[S[0] + 1][S[1] - 1] = (0, 0, 255)


def hough (bimg):
    data = []
    pii = math.pi
    threshold = len(bimg) / 3.3
    for i in range(len(bimg)):
        for j in range(len(bimg[0])):
            if bimg[i][j] == 255:
                data.append([i, j])

    maxr = int( math.sqrt(math.pow(len(bimg),2) + math.pow(len(bimg[0]),2) ) )
    H = np.zeros((maxr,360)) 

    for S in data:
        for i in range(0,360):
            theta = i * pii / 180
            rho = int(math.fabs(S[1]*math.cos(theta) + S[0]*math.sin(theta)))
            #print(rho)
            H[rho][i] += 1

    #dimg = np.zeros((len(img),len(img[0])))
    #dimg = (dimg).astype('uint8')
    dimg = cv.imread('lines.jpg')
    for i in range(len(H)):
        for j in range(len(H[i])):
            if H[i][j] > threshold:
                hough_lines_draw(dimg,i,j)
    cv.imshow('result', dimg)
    
            





img = cv.imread('lines.jpg',0)
xx = len(img)
yy = len(img[0])
cv.imshow('origin', img)

outline = np.array( [[-1,-1,-1],
                    [-1,8,-1],
                    [-1,-1,-1]])

img = cv.filter2D(img,-1,outline)
cv.imshow('outlined',img)

bimg = np.zeros((xx,yy))
bimg = (bimg).astype('uint8')
for i in range(xx):
    for j in range(yy):
        if img[i][j] < 180:
            bimg[i][j] = 0
        else:
            bimg[i][j] = 255

cv.imshow('binarized', bimg)

#img = cv.threshold(img,225,255,cv.THRESH_BINARY)
#cv.imshow('binarized', img[1])

hough(bimg)

cv.waitKey(0)
cv.destroyAllWindows()

